package com.study.swmssustem.service;

import com.study.swmssustem.dao.AdminDao;
import com.study.swmssustem.domin.Admins;
import com.study.swmssustem.domin.UserLogin;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;


import java.util.List;

@Service
public class AdminsService implements adminService{
    @Autowired
    private AdminDao adminDao;
    @Override
    public void save(Admins admins){adminDao.save(admins);}
    @Override
    public Admins search(String id){return  adminDao.search(id);}
    @Override
    public List<Admins> search(){return adminDao.search();}
    @Override
    public void delete(String id){
        adminDao.delete(id);
    }
    @Override
    public String login(UserLogin userLogin){
        Admins admins = new Admins();
        admins = search(userLogin.getId());
       if(admins.getId()==null)
            return "false";
        else if(admins.getPassword().equals(userLogin.getPassword())){
            return "ok";
        }
        else return "failed";
      /*  String P1=admins.getPassword();
        String P2=userLogin.getPassword();

     /*  if(admins.getId()==null) {
          /* return "falsee";
           if (!P1.equals(P2)) {
               return "true";
           } else return "falsse";
       }
        else return "falsesss";*/

    }
    @Override
    public void update(Admins admins){
        adminDao.update(admins);
    }
}
