package com.study.swmssustem.controller;

import com.study.swmssustem.domin.Students;
import com.study.swmssustem.service.StudentsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.relational.core.sql.In;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/student")
public class StudentController {
    @Autowired
    private StudentsService studentsService;
    @RequestMapping("/save")
    public String save(Students students){
        if(students.getId()!=null){
            studentsService.save(students);
            return "true";
        }
        else return "failed";
    }
    @RequestMapping(value = "/findByStudentid/{id}",method = RequestMethod.GET)
    public Students search(@PathVariable("id") String id){
        if(id!=null)
        return studentsService.search(id);
        else return null;
    }
    @RequestMapping("/findAllStudent")
    public List<Students> searchAll(){
        List<Students> list = new ArrayList<Students>();
        list=studentsService.search();
        return list;
    }
    @RequestMapping("/deleteByStudentid")
    public String delete(String id){
        if(id!=null){
            studentsService.delete(id);
            return "ok";
        }
        else return "failed";
    }
    @RequestMapping("/UpdateByStudentid")
    public String update(Students students){
        studentsService.update(students);
        return "true";
    }

}
