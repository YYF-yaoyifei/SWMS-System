package com.study.swmssustem.service;

import com.study.swmssustem.dao.StudentDao;
import com.study.swmssustem.domin.Admins;
import com.study.swmssustem.domin.Students;
import com.study.swmssustem.domin.UserLogin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.relational.core.sql.In;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentsService implements studentService{
    @Autowired
    private StudentDao studentDao;
    @Override
    public void save(Students students){ studentDao.save(students);}
    @Override
    public Students search(String id){return studentDao.search(id);}
    @Override
    public List<Students> search(){return studentDao.search();}
    @Override
    public void delete(String id){studentDao.delete(id);}
    @Override
    public void update(Students students){
        studentDao.update(students);
    }
    @Override
    public String login(UserLogin userLogin){
        /*Admins admins = new Admins();
        admins = search(userLogin.getId());
        if(admins.getId()==null)
            return "failed";
        else if(admins.getPassword().equals(userLogin.getPassword())){
            return "ok";
        }
        else return "failed";*/
        Students students = new Students();
        students = search(userLogin.getId());
        if(students.getId()==null)
            return "false";
        else if(students.getPassword().equals(userLogin.getPassword())){
            return "ok";
        }
        else return "failed";
       // return "er";
    }
}
