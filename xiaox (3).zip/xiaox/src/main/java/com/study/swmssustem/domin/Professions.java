package com.study.swmssustem.domin;

public class Professions {
    private String prpfessionid;
    private String professionname;
    private int year;
    private int classnumber;

    public String getPrpfessionid() {
        return prpfessionid;
    }

    public void setPrpfessionid(String prpfessionid) {
        this.prpfessionid = prpfessionid;
    }

    public String getProfessionname() {
        return professionname;
    }

    public void setProfessionname(String professionname) {
        this.professionname = professionname;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getClassnumber() {
        return classnumber;
    }

    public void setClassnumber(int classnumber) {
        this.classnumber = classnumber;
    }
}
