package com.study.swmssustem.service;

import com.study.swmssustem.domin.Students;
import com.study.swmssustem.domin.UserLogin;


import java.util.List;

public interface studentService {
    void save(Students students);
    Students search(String id);
    List<Students> search();
    void delete(String id);
    void update(Students students);
    String login(UserLogin userLogin);
}
