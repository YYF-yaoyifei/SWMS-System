package com.study.swmssustem.dao;

import com.study.swmssustem.domin.Teachers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;


@Repository
public class TeacherDao {
    @Autowired
    private JdbcTemplate jdbcTemplate;
    public void save(Teachers teachers){
        jdbcTemplate.update("insert into teacher(id,name,sex,password,age,departmentid,phonenumber,email) values (?,?,?,?,?,?,?,?)",teachers.getId(),teachers.getName(),teachers.getSex(),teachers.getPassword(),teachers.getAge(),teachers.getDepartment(),teachers.getPhonenumber(),teachers.getEmail());

    }
    public Teachers search(String id){
        SqlRowSet queryForRowSet = jdbcTemplate.queryForRowSet("select * from teacher where id=?",id);
        Teachers teachers= new Teachers();
        if(queryForRowSet.next()){
            teachers.setId(queryForRowSet.getString("id"));
            teachers.setName(queryForRowSet.getString("name"));
            teachers.setSex(queryForRowSet.getString("sex"));
            teachers.setPassword(queryForRowSet.getString("password"));
            teachers.setAge(queryForRowSet.getInt("age"));
            teachers.setDepartment(queryForRowSet.getString("departmentid"));
            teachers.setPhonenumber(queryForRowSet.getString("phonenumber"));
            teachers.setEmail(queryForRowSet.getString("email"));
        }
        return teachers;
    }
    public List<Teachers> search(){
        SqlRowSet queryForRowSet = jdbcTemplate.queryForRowSet("select * from teacher");
        List<Teachers> list = new ArrayList<Teachers>();
        while (queryForRowSet.next()){
            Teachers teachers = new Teachers();
            teachers.setId(queryForRowSet.getString("id"));
            teachers.setName(queryForRowSet.getString("name"));
            teachers.setSex(queryForRowSet.getString("sex"));
            teachers.setPassword(queryForRowSet.getString("password"));
            teachers.setAge(queryForRowSet.getInt("age"));
            teachers.setDepartment(queryForRowSet.getString("departmentid"));
            teachers.setPhonenumber(queryForRowSet.getString("phonenumber"));
            teachers.setEmail(queryForRowSet.getString("email"));
            list.add(teachers);
        }
        return list;
    }
    public void delete(String id){jdbcTemplate.update("delete from tearcher where id = ?",id);}
    public void update(Teachers teachers){
        delete(teachers.getId());
        update(teachers);
    }
}
