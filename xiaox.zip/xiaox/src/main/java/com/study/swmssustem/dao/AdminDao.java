package com.study.swmssustem.dao;
import com.study.swmssustem.domin.Admins;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository

public class AdminDao {
    @Autowired
    private JdbcTemplate jdbcTemplate;
    /*保存一个admin信息*/
    public void save(Admins admins){
        jdbcTemplate.update("insert into admin (id,name,sex,department,phonenumber,email,age,password) values (?,?,?,?,?,?,?,?)",admins.getId(),admins.getName(),admins.getSex(),admins.getDepartmentid(),admins.getPhonenumber(),admins.getEmail(),admins.getAge(),admins.getPassword());
    }
    /*根据name查找一个admin信息*/
  /*  public Admins search(String name){

    }
    /*根据id查找一个admin信息*/
    public Admins search(String id){
        SqlRowSet queryForRoeSet = jdbcTemplate.queryForRowSet("select * from admin where id=?",id);
        Admins admins = new Admins();
        if(queryForRoeSet.next()){
            admins.setId(queryForRoeSet.getString("id"));
            admins.setAge(queryForRoeSet.getInt("age"));
            admins.setDepartmentid(queryForRoeSet.getString("department"));
            admins.setEmail(queryForRoeSet.getString("email"));
            admins.setName(queryForRoeSet.getString("name"));
            admins.setPassword(queryForRoeSet.getString("password"));
            admins.setPhonenumber(queryForRoeSet.getString("phonenumber"));
            admins.setSex(queryForRoeSet.getString("sex"));
        }
        return admins;
    }
    /*返回所有admin信息*/
    public List<Admins> search(){
        SqlRowSet queryForRoeSet = jdbcTemplate.queryForRowSet("select * from admin");
        List<Admins> list = new ArrayList<Admins>();
        while (queryForRoeSet.next()){
            Admins admins = new Admins();
            admins.setId(queryForRoeSet.getString("id"));
            admins.setAge(queryForRoeSet.getInt("age"));
            admins.setDepartmentid(queryForRoeSet.getString("department"));
            admins.setEmail(queryForRoeSet.getString("email"));
            admins.setName(queryForRoeSet.getString("name"));
            admins.setPassword(queryForRoeSet.getString("password"));
            admins.setPhonenumber(queryForRoeSet.getString("phonenumber"));
            admins.setSex(queryForRoeSet.getString("sex"));
            list.add(admins);
        }
      /*  for(int i=0;i<list.size()-1;i++){
            for(int j=0;j<list.size()-1-i;j++){
                Admins admins = new Admins();
                int a=Integer.parseInt(list.get(j).getId());
                int b=Integer.parseInt((list.get(j+1).getId()));
                if(a>b){
                    admins = list.get(j);
                    list.get(j)=list.get(j+1);
                }
            }
        }*/
        return list;

    }
    /*根据admin的id删除id为id的admin信息*/
    public void delete(int id){
        jdbcTemplate.update("delete from admin where id=?",id);
    }
}
