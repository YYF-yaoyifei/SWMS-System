package com.study.swmssustem.service;

import com.study.swmssustem.dao.AdminDao;
import com.study.swmssustem.domin.Admins;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminsService implements adminService{
    @Autowired
    private AdminDao adminDao;
    @Override
    public void save(Admins admins){adminDao.save(admins);}
    @Override
    public Admins search(String id){return  adminDao.search(id);}
    @Override
    public List<Admins> search(){return adminDao.search();}
    @Override
    public void delete(int id){
        adminDao.delete(id);
    }
    @Override
    public
}
