package com.study.swmssustem.domin;
import java.time.LocalDate;
import java.util.Date;

public class Announcements {
    private String announcementid;
    private String courseid;
    private String title;
    private String content;
    private Date pushtime;
}
/**公告*/