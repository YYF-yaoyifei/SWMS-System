package com.study.swmssustem.controller;

import com.study.swmssustem.domin.Admins;
import com.study.swmssustem.service.AdminsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/admin")
public class AdminController {
    @Autowired
    private AdminsService adminsService;
    @RequestMapping("/save")
    public String save(Admins admins){
        if(admins.getId()!=null){
            adminsService.save(admins);
            /*return "searchAll";/** 返回数据库中所有数据*/
           /* return "login"/*返回登陆界面*/
            return "success";
        }
        else return "failed";
    }
    /**@RequestMapping("/search")
    public Object search(String id){
        if(id!=null){
            Admins admins = new Admins();
            admins = adminsService.search(id);
            return admins;
        }
        else
            return "error";
    }*/
    @GetMapping({"/findByAdminid/{id}"})
    public Admins search(@PathVariable(value = "id",required = false)String id, Model model){
        Admins admins = new Admins();
        if(id!=null){
            admins = adminsService.search(id);
            return admins;
        }
        else
            return null;
    }
    @RequestMapping("/findAllAdmin")
    public List<Admins> searchAll(){
        List<Admins> list = new ArrayList<Admins>();
        list = adminsService.search();
        return list;
    }
}
