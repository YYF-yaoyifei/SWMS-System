package com.study.swmssustem.controller;

import com.study.swmssustem.dao.AdminDao;
import com.study.swmssustem.domin.Admins;
import com.study.swmssustem.domin.UserLogin;
import com.study.swmssustem.service.AdminsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/User")
public class UserLoginController {
    @Autowired
    private AdminsService adminsService;
    @RequestMapping("/login")
    public String login(UserLogin userLogin){
        String ad="admin";
        String st="student";
        String te="teacher";
        String Type = userLogin.getType();
        String id=userLogin.getId();

      /**  if(Type.equals(ad)){
            Admins admins = new Admins();
            admins = adminsService.search(userLogin.getId());
            String userloginpassword = userLogin.getPassword();
            String adminpassword = admins.getPassword();
            if(admins!=null&&userloginpassword.equals(adminpassword)){
                return "success";
            }
            else return "false";
        }
        else return "false";
    }*/

}
