package com.study.swmssustem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwmssustemApplicationTests {

    @Test
    void contextLoads() {
    }

}
