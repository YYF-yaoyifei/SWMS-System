package com.alibaba;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlibabaApplicationTests {

    @Test
    void contextLoads() {
    }

}
