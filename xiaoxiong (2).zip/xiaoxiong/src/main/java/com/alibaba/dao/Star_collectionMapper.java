package com.alibaba.dao;

import com.alibaba.domain.Star_collections;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface Star_collectionMapper {
    public int uploadStarCollection(int uid, int star_cid);
    public List findStarCollections(int uid);//多条查询
    public Star_collections findStarCollection(int uid,int star_cid);//单条查询 空返回null 用于判断是否被收藏 同一个人收藏同一个博物馆不会在数据库中出现两次

}
