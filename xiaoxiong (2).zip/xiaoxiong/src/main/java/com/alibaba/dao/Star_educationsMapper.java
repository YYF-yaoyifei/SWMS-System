
package com.alibaba.dao;
import com.alibaba.domain.Star_educations;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;
@Mapper
public interface Star_educationsMapper {
    public int uploadStarEducation(int uid,int star_eid);
    public List findStarEducations(int uid);
    public Star_educations findStarEducation(int uid,int star_eid);
}
