package com.alibaba.dao;

import org.apache.ibatis.annotations.Mapper;
import java.util.List;
import com.alibaba.domain.Star_news;
@Mapper
public interface Star_newsMapper {
    public int uploadStarNew(int uid,int star_nid);
    public List findStarNews(int uid);
    public Star_news findStarNew(int uid, int star_nid);
}
