package com.alibaba.dao;
import com.alibaba.domain.Star_exhibitions;


import org.apache.ibatis.annotations.Mapper;
import java.util.List;
@Mapper
public interface Star_exhibitionsMapper {
    public int uploadStarExhibition(int uid,int star_eid);
    public List findStarExhibitions(int uid);
    public Star_exhibitions findStarExhibition(int uid,int star_eid);
}
