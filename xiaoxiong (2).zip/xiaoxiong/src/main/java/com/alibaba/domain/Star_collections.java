package com.alibaba.domain;

public class Star_collections {
    private int id;
    private int uid;
    private int star_cid;

    public int getId() {
        return id;
    }

    public int getUid() {
        return uid;
    }

    public int getStar_cid() {
        return star_cid;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public void setStar_cid(int star_cid) {
        this.star_cid = star_cid;
    }
}
