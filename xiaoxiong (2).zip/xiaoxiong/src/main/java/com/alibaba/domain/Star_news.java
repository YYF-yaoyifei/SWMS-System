package com.alibaba.domain;

public class Star_news {
    private int id;
    private int uid;
    private int star_nid;

    public int getId() {
        return id;
    }

    public int getUid() {
        return uid;
    }

    public int getStar_nid() {
        return star_nid;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public void setStar_nid(int star_uid) {
        this.star_nid = star_nid;
    }
}
