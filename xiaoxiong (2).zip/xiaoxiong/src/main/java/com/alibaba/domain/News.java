package com.alibaba.domain;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import java.util.Objects;

public class News {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer nid;

    //新闻可属于几个博物馆

    @NotNull
    @Column(length = 500)
    private String title;
    @Column(length = 2000)
    private String extract;//新闻摘要

    @Column(length = 9000)
    private String content;//新闻内容
    @NotNull
    @Column(length = 2000)
    private String url;//新闻来源网址
    @Column(length = 2000)
    private String imgurl;//图片
    @NotNull
    @Column(length = 500)
    private String author;//新闻作者
    @Column(length = 30)
    private String releasetime;//发布时间
    @NotNull
    private Integer nature=0;//正面新闻还是负面新闻

    @Column(length = 2000)
    private String sign;

    public Integer getNid() {
        return nid;
    }
    public void setNid(Integer nid) {
        this.nid = nid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getExtract() {
        return extract;
    }

    public void setExtract(String extract) {
        this.extract = extract;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getImgurl() {
        return imgurl;
    }

    public void setImgurl(String imgurl) {
        this.imgurl = imgurl;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getReleasetime() {
        return releasetime;
    }

    public void setReleasetime(String releasetime) {
        this.releasetime = releasetime;
    }

    public Integer getNature() {
        return nature;
    }

    public void setNature(Integer nature) {
        this.nature = nature;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        News news = (News) o;
        return nid.equals(news.nid);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nid);
    }
}
