package com.alibaba.domain;

public class Star_exhibitions {
    private int id;
    private int uid;
    private int star_eid;

    public int getId() {
        return id;
    }

    public int getUid() {
        return uid;
    }

    public int getStar_eid() {
        return star_eid;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public void setStar_eid(int star_eid) {
        this.star_eid = star_eid;
    }
}

