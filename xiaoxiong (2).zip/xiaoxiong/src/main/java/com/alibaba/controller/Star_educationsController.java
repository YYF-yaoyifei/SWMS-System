package com.alibaba.controller;
import com.alibaba.domain.Star_educations;
import com.alibaba.service.Star_educationsService;

import javax.annotation.Resource;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@ComponentScan({"com.alibaba.service.Star_educationsService"})
@MapperScan({"com.alibaba.dao"})
public class Star_educationsController {
    @Resource
    private Star_educationsService star_educationsService;
    @RequestMapping(value = "/star/uploadStarEducation/{uid}/{star_eid}",method = RequestMethod.GET)
    public String UploadStarEducation(@PathVariable Integer uid,@PathVariable Integer star_eid){
        return star_educationsService.uploadStarEducation(uid,star_eid);
    }


    @RequestMapping(value = "/star/findStarEducation/{uid}",method = RequestMethod.GET)
    public List<Star_educations> findStarEducation(@PathVariable("uid") Integer uid){
        return star_educationsService.findStarEducations(uid);
    }


    @RequestMapping(value = "/star/isStarEducation/{uid}/{star_eid}",method = RequestMethod.GET)
    public int isStarEducation(@PathVariable Integer uid,@PathVariable Integer star_eid){
        return star_educationsService.isStarEducation(uid,star_eid);
    }
}
