package com.alibaba.controller;
import javax.annotation.Resource;


import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.domain.Star_news;
import com.alibaba.service.Star_newsService;

import java.util.List;
@RestController
@ComponentScan({"com.alibaba.service.Star_newService"})
@MapperScan({"com.alibaba.dao"})
public class Star_newsController {

    @Resource
    private Star_newsService star_newsService;
    @RequestMapping(value = "/star/uploadStarNews/{uid}/{star_nid}",method = RequestMethod.GET)
    public String UploadStarNew(@PathVariable Integer uid,@PathVariable Integer star_nid){
        return star_newsService.uploadStarNew(uid,star_nid);
    }

    @RequestMapping(value = "/star/findStarNew/{uid}",method = RequestMethod.GET)
    public List<Star_news> findStarNew(@PathVariable("uid") Integer uid){
        return star_newsService.findStarNews(uid);
    }
    @RequestMapping(value = "/star/isStarNew/{uid}/{star_nid}",method = RequestMethod.GET)
    public int isStarNew(@PathVariable Integer uid,@PathVariable Integer star_nid){
        return star_newsService.isStarNew(uid,star_nid);
    }
}
