package com.alibaba.controller;
import com.alibaba.domain.Star_exhibitions;
import com.alibaba.service.Star_exhibitionsService;


import javax.annotation.Resource;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
@RestController
@ComponentScan({"com.alibaba.service.Star_exhibitionsService"})
@MapperScan({"com.alibaba.dao"})
public class Star_exhibitionsController {
    @Resource
    private Star_exhibitionsService star_exhibitionsService;
    @RequestMapping(value = "/star/uploadStarExhibition/{uid}/{star_eid}",method = RequestMethod.GET)
    public String UploadStarExhibition(@PathVariable Integer uid,@PathVariable Integer star_eid){
        return star_exhibitionsService.uploadStarExhibition(uid,star_eid);
    }

    @RequestMapping(value = "/star/findStarExhibition/{uid}",method = RequestMethod.GET)
    public List<Star_exhibitions> findStarExhibition(@PathVariable("uid") Integer uid){
        return star_exhibitionsService.findStarExhibitions(uid);
    }
    @RequestMapping(value = "/star/isStarExhibition/{uid}/{star_eid}",method = RequestMethod.GET)
    public int isStarExhibition(@PathVariable Integer uid,@PathVariable Integer star_eid){
        return star_exhibitionsService.isStarExhibition(uid,star_eid);
    }
}
