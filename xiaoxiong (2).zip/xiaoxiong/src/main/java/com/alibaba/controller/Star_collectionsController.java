package com.alibaba.controller;
import com.alibaba.domain.Star_collections;
import com.alibaba.service.Star_collectionsService;
import javax.annotation.Resource;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@RestController
@ComponentScan({"com.alibaba.service.Star_collectionsService"})
@MapperScan({"com.alibaba.dao"})
public class Star_collectionsController {
    @Resource
    private Star_collectionsService star_collectionsService;
    @RequestMapping(value = "/star/uploadStarCollection/{uid}/{star_cid}",method = RequestMethod.GET)
    public String uploadStarCollection(@PathVariable Integer uid,@PathVariable Integer star_cid){
        return star_collectionsService.uploadStarCollection(uid,star_cid);

    }
    @RequestMapping(value = "/star/findStarCollection/{uid}",method = RequestMethod.GET)
    public List<Star_collections> findStarCollections(@PathVariable("uid") Integer uid){

     return star_collectionsService.findStarCollections(uid);
    }
    @RequestMapping(value = "/star/isStarCollection/{uid}/{star_cid}",method = RequestMethod.GET)
    public int isStarExhibition(@PathVariable Integer uid,@PathVariable Integer star_cid){
         return star_collectionsService.isStarCollection(uid,star_cid);//若有返回1
    }
}
