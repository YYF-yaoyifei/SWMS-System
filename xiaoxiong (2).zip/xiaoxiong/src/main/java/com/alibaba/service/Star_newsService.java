package com.alibaba.service;
import javax.annotation.Resource;
import java.util.List;


import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

import com.alibaba.dao.Star_newsMapper;
@ComponentScan({"Star_news"})
@Service("star_newsService")
public class Star_newsService {
    @Resource
    private Star_newsMapper star_newsMapperr;
    public  List findStarNews(int uid){
        return star_newsMapperr.findStarNews(uid);
    }
    public int isStarNew(int uid,int star_nid){
        if(star_newsMapperr.findStarNew(uid, star_nid)==null){
            return 0;
        }
        else return 1;
    }
    public String uploadStarNew(int uid, int star_nid) {

        if(isStarNew(uid,star_nid)==0) {
            star_newsMapperr.uploadStarNew(uid, star_nid);
            return "1";
        }
        return "0";
    }
}
