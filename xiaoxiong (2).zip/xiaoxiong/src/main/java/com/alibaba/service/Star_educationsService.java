package com.alibaba.service;
import javax.annotation.Resource;
import javax.servlet.http.PushBuilder;
import java.util.List;
import java.net.PortUnreachableException;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;
import com.alibaba.domain.Star_educations;
import com.alibaba.dao.Star_educationsMapper;
@ComponentScan({"Star_educationsMapper"})
@Service("star_educationService")
public class Star_educationsService {
    @Resource
    private Star_educationsMapper star_educationsMapper;
    public  List findStarEducations(int uid){
        return star_educationsMapper.findStarEducations(uid);
    }
    public int isStarEducation(int uid,int star_eid){
        if(star_educationsMapper.findStarEducation(uid, star_eid)==null){
            return 0;
        }
        else return 1;
    }
    public String uploadStarEducation(int uid, int star_eid) {

     if(isStarEducation(uid,star_eid)==0) {
     star_educationsMapper.uploadStarEducation(uid, star_eid);
     return "1";
 }
 return "0";
 }
}
