package com.alibaba.service;
import javax.annotation.Resource;
import java.util.List;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;

import com.alibaba.dao.Star_exhibitionsMapper;
import com.alibaba.domain.Star_exhibitions;

@ComponentScan({"Star_exhibitions"})
@Service("star_exhibitionService")
public class Star_exhibitionsService {
    @Resource
    private Star_exhibitionsMapper star_exhibitionsMapper;
    public  List findStarExhibitions(int uid){
        return star_exhibitionsMapper.findStarExhibitions(uid);
    }
    public int isStarExhibition(int uid,int star_eid){
        if(star_exhibitionsMapper.findStarExhibition(uid, star_eid)==null){
            return 0;
        }
        else return 1;
    }
    public String uploadStarExhibition(int uid, int star_eid) {

        if(isStarExhibition(uid,star_eid)==0) {
            star_exhibitionsMapper.uploadStarExhibition(uid, star_eid);
            return "1";
        }
        return "0";
    }
}
