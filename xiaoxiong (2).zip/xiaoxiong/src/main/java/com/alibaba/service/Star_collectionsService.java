package com.alibaba.service;
import javax.annotation.Resource;
import javax.servlet.http.PushBuilder;

import com.alibaba.domain.Star_collections;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;
import com.alibaba.dao.Star_collectionMapper;

import java.net.PortUnreachableException;
import java.util.List;

@ComponentScan({"Star_collectionMapper"})
@Service("star_collectionService")
public class Star_collectionsService {
    @Resource
    private Star_collectionMapper star_collectionMapper;



    public List findStarCollections(int uid){
        return star_collectionMapper.findStarCollections(uid);
    }
    public int isStarCollection(int uid,int star_cid){
        if(star_collectionMapper.findStarCollection(uid, star_cid)==null){
            return 0;
        }
        else return 1;
    }
    public String uploadStarCollection(int uid, int star_cid) {
        /** if(star_collectionMapper.findStarCollection(uid,star_cid)!=null){
         return "你已经收藏过了";
         }*/
        if(isStarCollection(uid,star_cid)==0) {
             star_collectionMapper.uploadStarCollection(uid, star_cid);
             return "1";
        }
        return "0";
    }
}
