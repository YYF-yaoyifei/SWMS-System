package com.study.swmssustem.service;

import com.study.swmssustem.dao.TeacherDao;
import com.study.swmssustem.domin.Students;
import com.study.swmssustem.domin.Teachers;
import com.study.swmssustem.domin.UserLogin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TeachersService implements teacherService{
    @Autowired
    private TeacherDao teacherDao;
    @Override
    public void save(Teachers teachers){teacherDao.save(teachers);}
    @Override
    public Teachers search(String id){
        return teacherDao.search(id);
    }
    @Override
    public List<Teachers> search(){
        return teacherDao.search();
    }
    @Override
    public void delete(String id){
        teacherDao.delete(id);
    }
    @Override
    public void update(Teachers teachers){
        teacherDao.update(teachers);
    }
    @Override
    public  String login(UserLogin userLogin){
        /*Students students = new Students();
        students = search(userLogin.getId());
        if(students.getId()==null)
            return "failed";
        else if(students.getPassword().equals(userLogin.getPassword())){
            return "ok";
        }
        else return "failed";*/
        Teachers teachers = new Teachers();
        teachers = search(userLogin.getId());
        if (teachers.getId()==null)
            return "false";
        else if(teachers.getPassword().equals(userLogin.getPassword())){
            return "ok";
        }
        else return "failed";
    }
}
