package com.study.swmssustem.controller;

import com.study.swmssustem.domin.Students;
import com.study.swmssustem.domin.Teachers;
import com.study.swmssustem.service.TeachersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/teacher")
public class TeacherController {
    @Autowired
    private TeachersService teachersService;
    @RequestMapping("/save")
    public String save(Teachers teachers){
        teachersService.save(teachers);
        return "seccussful";
    }
    @RequestMapping(value = "/findByTeacherid/{id}",method = RequestMethod.GET)
    public Teachers search(String id){
        if(id!=null){
            return  teachersService.search(id);
        }
        else return null;
    }
    @RequestMapping("/findAllTeacher")
    public List<Teachers>  searchAll(){
        List<Teachers> list = new ArrayList<Teachers>();
        list = teachersService.search();
        return list;

    }
    @RequestMapping("/deleteByTeacherid")
    public String delete(String id){
        if(id!=null){
            teachersService.delete(id);
            return "ok";
        }
        else return "failed";
    }
    @RequestMapping("/UpdateByTeacherid")
    public String update(Teachers teachers){
        teachersService.update(teachers);
        return "true";
    }
}
