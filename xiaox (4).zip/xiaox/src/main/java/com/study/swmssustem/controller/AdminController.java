package com.study.swmssustem.controller;

import com.study.swmssustem.dao.AdminDao;
import com.study.swmssustem.domin.Admins;
import com.study.swmssustem.service.AdminsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/admin")
public class AdminController {
    @Autowired
    private AdminsService adminsService;
    @RequestMapping("/save")
    public String save(Admins admins){
        if(admins.getId()!=null){
            adminsService.save(admins);
            /*return "searchAll";/** 返回数据库中所有数据*/
           /* return "login"/*返回登陆界面*/
            return "success";
        }
        else return "failed";
    }
    /**@RequestMapping("/search")
    public Object search(String id){
        if(id!=null){
            Admins admins = new Admins();
            admins = adminsService.search(id);
            return admins;
        }
        else
            return "error";
    }*/
    @RequestMapping(value = "/findByAdminid/{id}",method = RequestMethod.GET)
    public Admins search(@PathVariable("id") String id){
        Admins admins = new Admins();
        if(id!=null){
            admins = adminsService.search(id);
            return admins;
        }
        else
            return null;
    }
    @RequestMapping("/findAllAdmin")
    public List<Admins> searchAll(){
        List<Admins> list = new ArrayList<Admins>();
        list = adminsService.search();
        return list;
    }
    @RequestMapping({"/UpdateByAdminid"})
    public String update(Admins admins){
        adminsService.update(admins);
        return "true";
    }
    @RequestMapping(value = {"/deleteByAdminid/{id}"},method = RequestMethod.GET)
    public String delete(@PathVariable("id") String id){
        adminsService.delete(id);
        return "ok";
    }


}
