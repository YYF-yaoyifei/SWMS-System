package com.study.swmssustem.controller;

import com.study.swmssustem.dao.AdminDao;
import com.study.swmssustem.domin.Admins;
import com.study.swmssustem.domin.UserLogin;
import com.study.swmssustem.service.AdminsService;
import com.study.swmssustem.service.StudentsService;
import com.study.swmssustem.service.TeachersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/User")
public class UserLoginController {
    @Autowired
    private AdminsService adminsService;
    @Autowired
    private StudentsService studentsService;
    @Autowired
    private TeachersService teachersService;

    @RequestMapping("/login")
    public String login(UserLogin userLogin) {

            String ad = "admin";
            String st = "student";
            String te = "teacher";
            String Type = userLogin.getType();
            String id = userLogin.getId();
//return userLogin.getType();
           if (ad.equals(Type)) {

                return adminsService.login(userLogin);

            }
            else if (st.equals(Type)){
                return studentsService.login(userLogin);
            }
            else
                return teachersService.login(userLogin);

     //   return userLogin.getType();
//return userLogin.getPassword();
    }
}