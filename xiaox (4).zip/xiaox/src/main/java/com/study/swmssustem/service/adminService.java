package com.study.swmssustem.service;

import com.study.swmssustem.domin.Admins;
import com.study.swmssustem.domin.UserLogin;


import java.util.List;

public interface adminService {
    void save (Admins admins);
    Admins search (String id);
    List<Admins> search();
    void  delete(String id);
    void  update(Admins admins);
    String login(UserLogin userLogin);
}
