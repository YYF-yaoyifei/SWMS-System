package com.study.swmssustem.dao;

import com.study.swmssustem.domin.Announcements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class AnnouncementDao {
    @Autowired
    private JdbcTemplate jdbcTemplate;
    public void save(Announcements announcements){
    jdbcTemplate.update("insert into announcement (announcementid,courseid,title,content,pushtime) values (?,?,?,?,?)",announcements.getAnnouncementid(),announcements.getCourseid(),announcements.getTitle(),announcements.getContent(),announcements.getPushtime());
    }
    public Announcements search (String announcementid){
        SqlRowSet queryForRowSet = jdbcTemplate.queryForRowSet("select * from announcement where annocementid=?",announcementid);
        Announcements announcements = new Announcements();
        if(queryForRowSet.next()){
            announcements.setAnnouncementid(queryForRowSet.getString("announcementid"));
            announcements.setCourseid(queryForRowSet.getString("courseid"));
            announcements.setTitle(queryForRowSet.getString("title"));
            announcements.setContent(queryForRowSet.getString("content"));
            announcements.setPushtime(queryForRowSet.getTime("pushtime"));
        }
        return announcements;
    }
    public List<Announcements> search(){
        SqlRowSet queryForRowSet = jdbcTemplate.queryForRowSet("select * from announcement");
        List<Announcements> list = new ArrayList<Announcements>();
        while (queryForRowSet.next()){
            Announcements announcements = new Announcements()  ;
            announcements.setAnnouncementid(queryForRowSet.getString("announcementid"));
            announcements.setCourseid(queryForRowSet.getString("courseid"));
            announcements.setTitle(queryForRowSet.getString("title"));
            announcements.setContent(queryForRowSet.getString("content"));
            announcements.setPushtime(queryForRowSet.getTime("pushtime"));
            list.add(announcements);
        }
        return  list;
    }
    public void delete(String announcementid){
        jdbcTemplate.update("delete from announcement where announcementid=?",)
    }
}
