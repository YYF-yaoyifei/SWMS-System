package com.study.swmssustem.service;

import com.study.swmssustem.domin.Teachers;
import com.study.swmssustem.domin.UserLogin;
import org.apache.catalina.User;

import java.util.List;

public interface teacherService {
    void save(Teachers teachers);
    Teachers search (String id);
    List<Teachers> search ();
    void delete(String id);
    void update(Teachers teachers);
    String login(UserLogin userLogin);
}
