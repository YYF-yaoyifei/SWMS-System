package com.study.swmssustem.domin;

import java.util.Date;

public class Choosecourses {
    private String studentid;
    private String courseid;
    private String teachername;
    private Date starttime;
    private Date enddtime;

    public String getStudentid() {
        return studentid;
    }

    public void setStudentid(String studentid) {
        this.studentid = studentid;
    }

    public String getCourseid() {
        return courseid;
    }

    public void setCourseid(String courseid) {
        this.courseid = courseid;
    }

    public String getTeachername() {
        return teachername;
    }

    public void setTeachername(String teachername) {
        this.teachername = teachername;
    }

    public Date getStarttime() {
        return starttime;
    }

    public void setStarttime(Date starttime) {
        this.starttime = starttime;
    }

    public Date getEnddtime() {
        return enddtime;
    }

    public void setEnddtime(Date enddtime) {
        this.enddtime = enddtime;
    }
}
