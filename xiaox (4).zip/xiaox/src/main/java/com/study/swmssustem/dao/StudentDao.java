package com.study.swmssustem.dao;

import com.study.swmssustem.domin.Students;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class StudentDao {
    @Autowired
    private JdbcTemplate jdbcTemplate;
    public void save(Students students){
        jdbcTemplate.update("insert into student (sex,id,name,department,phonenumber,email,age,password,classid,professionid) values (?,?,?,?,?,?,?,?,?,?)",students.getSex(),students.getId(),students.getName(),students.getDepartment(),students.getPhonenumber(),students.getEmail(),students.getAge(),students.getPassword(),students.getClassid(),students.getProfession());
    }
    public Students search (String id){
        SqlRowSet queryForRowSet = jdbcTemplate.queryForRowSet("select * from student where id=?",id);
        Students students = new Students();
        if(queryForRowSet.next()){
            students.setAge(queryForRowSet.getInt("age"));
            students.setClassid(queryForRowSet.getString("classid"));
            students.setDepartment(queryForRowSet.getString("departmentid"));
            students.setEmail(queryForRowSet.getString("email"));
            students.setId(queryForRowSet.getString("id"));
            students.setName(queryForRowSet.getString("name"));
            students.setPassword((queryForRowSet.getString("password")));
            students.setPhonenumber(queryForRowSet.getString("phonenumber"));
            students.setProfession(queryForRowSet.getString("professionid"));
            students.setSex(queryForRowSet.getString("sex"));
        }
        return students;
    }
    public List<Students> search(){
        SqlRowSet queryForRowSet = jdbcTemplate.queryForRowSet("select * from student; ");
        List<Students> list = new ArrayList<Students>();
        while ((queryForRowSet.next())){
            Students students = new Students();
            students.setAge(queryForRowSet.getInt("age"));
            students.setClassid(queryForRowSet.getString("classid"));
            students.setDepartment(queryForRowSet.getString("departmentid"));
            students.setEmail(queryForRowSet.getString("email"));
            students.setId(queryForRowSet.getString("id"));
            students.setName(queryForRowSet.getString("name"));
            students.setPassword((queryForRowSet.getString("password")));
            students.setPhonenumber(queryForRowSet.getString("phonenumber"));
            students.setProfession(queryForRowSet.getString("professionid"));
            students.setSex(queryForRowSet.getString("sex"));
            list.add(students);
        }
        return list;
    }
    public void delete(String id){
        jdbcTemplate.update("delete from student where id = ?",id);
    }
    public void update(Students students){
        delete(students.getId());
        save(students);
    }

}
